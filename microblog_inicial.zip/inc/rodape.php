    </main>


<footer class="footer bg-light border-top">
  <div class="container text-center">
    <span class="text-muted">
      Microblog é um site fictício desenvolvido para fins didáticos | Senac Penha &copy; 2021
    </span>
  </div>
</footer>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>



</body>
</html>
