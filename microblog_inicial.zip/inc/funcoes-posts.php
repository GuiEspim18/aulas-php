<?php
require "conecta.php";

/* Usada em post-insere.php */
function inserePost($conexao){
    
    mysqli_query($conexao, $sql) or die(mysqli_error($conexao));
} // fim inserePost



/* Usada em post-atualiza.php */
function listaUmPost($conexao){    
    


	$resultado = mysqli_query($conexao, $sql) or die(mysqli_error($conexao));
    return mysqli_fetch_assoc($resultado); 
} // fim listaUmPost



/* Usada em post-atualiza.php */
function atualizaPost($conexao){
    

    mysqli_query($conexao, $sql) or die(mysqli_error($conexao));       
} // fim atualizaPost



/* Usada em post-exclui.php */
function excluiPost($conexao){
    

	mysqli_query($conexao, $sql) or die(mysqli_error($conexao));
} // fim excluiPost



/* Usada em posts.php */
function listaPosts($conexao){
    

    $resultado = mysqli_query($conexao,$sql) or die(mysqli_error($conexao));
    $posts = [];
    while($post = mysqli_fetch_assoc($resultado)){
        array_push($posts, $post);
    }
    return $posts;
} // fim listaPosts



/* Usada em post-insere.php e post-atualiza.php */
function upload($arquivo){
    $tiposValidos = [
        "image/png","image/jpeg", "image/gif", "image/svg+xml"
    ];

    if( !in_array($arquivo["type"], $tiposValidos) ){
        die("<script>alert('Formato inválido. Tente novamente.');history.back();</script>");
    }

    $nome = $arquivo["name"]; 
    $temp = $arquivo["tmp_name"];

    $destino = "../imagens/".$nome;

    if(move_uploaded_file($temp, $destino)){
        return true;
    }
} // fim upload




/*** Funções para a área PÚBLICA do site ***/

/* Usada em index.php */
function lerTodosOsPosts($conexao){
    
    
    $resultado = mysqli_query($conexao, $sql) or die(mysqli_error($conexao));
    $posts = [];
    while( $post = mysqli_fetch_assoc($resultado) ){
        array_push($posts, $post);
    }
    return $posts; 
} // fim lerTodosOsPosts



/* Usada em post-detalhe.php */
function lerDetalhes($conexao){    
    

    $resultado = mysqli_query($conexao, $sql) or die(mysqli_error($conexao));
    return mysqli_fetch_assoc($resultado); 
} // fim lerDetalhes



/* Usada em search.php */
function busca($conexao){
    
        
    $resultado = mysqli_query($conexao, $sql) or die(mysqli_error($conexao));
    $posts = [];
    while( $post = mysqli_fetch_assoc($resultado) ){
        array_push($posts, $post);
    }
    return $posts; 
} // fim busca