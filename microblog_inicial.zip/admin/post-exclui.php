<?php
require "../inc/funcoes-posts.php";
require "../inc/funcoes-sessao.php";



